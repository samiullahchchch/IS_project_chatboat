# import os
# import logging
# from datetime import datetime, timedelta, timezone
# from functools import wraps
# from pathlib import Path
# from flask import Flask, render_template, redirect, url_for, request, flash, session
# from flask_login import login_user, login_required, logout_user, current_user
# from flask_sqlalchemy import SQLAlchemy
# from extensions import db, bcrypt, login_manager, mail
# from flask_mail import Message
# import random
# from models import User
# from forms import SignupForm, LoginForm
# from flask_migrate import Migrate


# def create_app():
#     # Initialize Flask App
#     app = Flask(__name__)

#     migrate = Migrate(app, db)

#     # Logging Configuration
#     logging.basicConfig(
#         filename='security.log',
#         level=logging.INFO,
#         format='%(asctime)s - %(levelname)s - %(message)s',
#         datefmt='%Y-%m-%d %H:%M:%S'
#     )
#     logger = logging.getLogger('zero_trust_auth')

#     # App Configuration
#     app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'fallback-secret-key-change-me')
#     app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(minutes=15)

#     # Database Configuration
#     instance_path = Path(app.instance_path)
#     instance_path.mkdir(exist_ok=True)
#     app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{instance_path}/users.db'
#     app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

#     # Flask-Mail Configuration
#     app.config['MAIL_SERVER'] = 'smtp.gmail.com'
#     app.config['MAIL_PORT'] = 587
#     app.config['MAIL_USE_TLS'] = True
#     app.config['MAIL_USERNAME'] = 'sami325532@gmail.com'
#     app.config['MAIL_PASSWORD'] = 'mhof wdnf kamu zqro'
#     app.config['MAIL_DEFAULT_SENDER'] = 'sami325532@gmail.com'
#   # Same as MAIL_USERNAME

#     # Secure Session Handling
#     app.config.update(
#         SESSION_COOKIE_SECURE=True,
#         SESSION_COOKIE_HTTPONLY=True,
#         SESSION_COOKIE_SAMESITE='Lax',
#         PERMANENT_SESSION_LIFETIME=timedelta(minutes=15),
#         SESSION_REFRESH_EACH_REQUEST=True
#     )

#     # Initialize Extensions
#     db.init_app(app)
#     bcrypt.init_app(app)
#     login_manager.init_app(app)
#     mail.init_app(app)

#     # Configure login manager
#     login_manager.login_view = 'login'

#     @login_manager.user_loader
#     def load_user(user_id):
#         return db.session.get(User, int(user_id))

#     @app.after_request
#     def add_security_headers(response):
#         csp = "default-src 'self'; style-src 'self' https://cdn.jsdelivr.net 'unsafe-inline'; script-src 'self' 'unsafe-eval';"
#         response.headers['Content-Security-Policy'] = csp
#         response.headers['X-Content-Type-Options'] = 'nosniff'
#         response.headers['X-Frame-Options'] = 'SAMEORIGIN'
#         response.headers['X-XSS-Protection'] = '1; mode=block'
#         return response

#     # Helper Functions
#     def get_user_ip():
#         """Get client IP with proxy consideration"""
#         return request.headers.get('X-Forwarded-For', request.remote_addr).split(',')[0].strip()

#     def log_security_event(event_type, user_id=None, details=None):
#         """Standardized security logging"""
#         log_data = {
#             'timestamp': datetime.now(timezone.utc).isoformat(),
#             'event': event_type,
#             'user_id': user_id,
#             'ip': get_user_ip(),
#             'details': details
#         }
#         logger.info(log_data)

#     # Re-Verification Decorator (Zero Trust)
#     def reverify_required(f):
#         @wraps(f)
#         def decorated_function(*args, **kwargs):
#             if not current_user.is_authenticated:
#                 log_security_event('unauthenticated_access_attempt', details=request.path)
#                 flash('You must be logged in to perform this action.')
#                 return redirect(url_for('login'))

#             # Check if the user needs re-verification
#             if not session.get('is_verified'):
#                 log_security_event('reverification_required', current_user.id, request.path)
#                 flash('Please re-verify your identity to proceed.')
#                 return redirect(url_for('verify_otp'))

#             return f(*args, **kwargs)
#         return decorated_function

#     # Routes
#     @app.route('/signup', methods=['GET', 'POST'])
#     def signup():
#         form = SignupForm()
#         if form.validate_on_submit():
#             try:
#                 # Create new user with Zero Trust defaults
#                 new_user = User(
#                     email=form.email.data,
#                     password=bcrypt.generate_password_hash(form.password.data).decode('utf-8'),
#                     role='user',
#                     is_active=True,
#                     mfa_enabled=True,
#                     failed_login_attempts=0,
#                     last_login_attempt=None
#                 )

#                 db.session.add(new_user)
#                 db.session.commit()

#                 log_security_event('user_registered', new_user.id)
#                 flash('Account created successfully. Please log in.')
#                 return redirect(url_for('login'))

#             except Exception as e:
#                 db.session.rollback()
#                 log_security_event('registration_failed', details=str(e))
#                 flash('An error occurred during registration. Please try again.')

#         return render_template('signup.html', form=form)

#     @app.route('/login', methods=['GET', 'POST'])
#     def login():
#         if current_user.is_authenticated:
#             return redirect(url_for('dashboard'))
    
#         form = LoginForm()
#         if form.validate_on_submit():
#             user = User.query.filter_by(email=form.email.data).first()
#             valid_user = False
    
#             if user:
#                 valid_user = bcrypt.check_password_hash(user.password, form.password.data)
    
#             if valid_user:
#                 if user.failed_login_attempts >= 5:
#                     flash('Account locked due to multiple failed login attempts. Please try again later.')
#                     return redirect(url_for('login'))
    
#                 # Successful login, check if MFA is enabled
#                 if user.mfa_enabled:
#                     session['user_id'] = user.id  # Store user session

#                     # Generate OTP
#                     otp = str(random.randint(100000, 999999))  # Generate OTP

#                     # Send OTP via email using Flask-Mail
#                     try:
#                         msg = Message(
#                             subject="Your OTP Code",
#                             recipients=[user.email],  # Send OTP to the user's email
#                             body=f"Your OTP code is: {otp}"
#                         )
#                         mail.send(msg)  # Send the email

#                         session['otp'] = otp  # Store OTP in session for verification later
#                         session['otp_expiry'] = datetime.now(timezone.utc).timestamp() + 300  # 5 minutes expiry

#                         log_security_event('mfa_required', user.id)  # Log MFA required event
#                         flash("OTP sent to your email. Please verify.")
#                         return redirect(url_for('verify_otp'))  # Redirect to OTP verification page

#                     except Exception as e:
#                         log_security_event('email_error', user.id, str(e))
#                         flash("Error sending OTP. Please try again.")
#                         return redirect(url_for('login'))

#                 login_user(user)
#                 session['is_verified'] = True  # Assuming user verification is passed
#                 user.failed_login_attempts = 0
#                 user.last_login_attempt = datetime.now(timezone.utc)
#                 db.session.commit()

#                 log_security_event('login_success', user.id)
#                 flash('Login successful!')
#                 return redirect(url_for('dashboard'))

#             else:
#                 if user:
#                     user.failed_login_attempts += 1
#                     user.last_login_attempt = datetime.now(timezone.utc)
#                     db.session.commit()
#                     log_security_event('failed_login', user.id, f"Attempts: {user.failed_login_attempts}")
#                 else:
#                     log_security_event('failed_login', None, "User not found")
    
#                 flash('Invalid credentials. Please try again.')
    
#         return render_template('login.html', form=form)

#     @app.route('/verify_otp', methods=['GET', 'POST'])
#     def verify_otp():
#         if 'user_id' not in session or 'otp' not in session:
#             flash('Invalid verification request.')
#             return redirect(url_for('login'))

#         user = db.session.get(User, session['user_id'])

#         if not user:
#             flash('Invalid verification request.')
#             session.clear()
#             return redirect(url_for('login'))

#         if request.method == 'POST':
#             otp = request.form.get('otp', '')

#             # Check OTP expiration
#             if datetime.now(timezone.utc).timestamp() > session.get('otp_expiry', 0):
#                 flash('Verification code has expired. Please try logging in again.')
#                 return redirect(url_for('login'))

#             if otp == session['otp']:
#                 # OTP verified successfully, log the user in
#                 login_user(user)
#                 session['is_verified'] = True
#                 session['verification_time'] = datetime.now(timezone.utc).timestamp()
#                 session.pop('otp', None)  # Clear OTP after successful verification
#                 session.pop('otp_expiry', None)  # Clear OTP expiry

#                 flash('Login successful!')
#                 return redirect(url_for('dashboard'))
#             else:
#                 flash('Invalid OTP. Please try again.')

#         return render_template('verify_otp.html')

#     @app.route('/dashboard')
#     @login_required
#     def dashboard():
#         # Check if re-verification is needed
#         if datetime.now(timezone.utc).timestamp() - session.get('verification_time', 0) > 1800:  # 30 minutes
#             session['is_verified'] = False
#             log_security_event('session_reverification_required', current_user.id)
#             flash('Your session requires re-verification.')
#             return redirect(url_for('verify_otp'))

#         return render_template('dashboard.html', user=current_user)

#     return app


# # Create the application
# app = create_app()

# if __name__ == '__main__':
#     with app.app_context():
#         db.create_all()  # Create tables if they don't exist
#         # Ensure there's an admin user for testing
#         if not User.query.first():
#             admin = User(
#                 email='admin@example.com',
#                 password=bcrypt.generate_password_hash('admin123').decode('utf-8'),
#                 role='admin',
#                 is_active=True
#             )
#             db.session.add(admin)
#             db.session.commit()
#     app.run(host='0.0.0.0', port=5000, debug=True)
