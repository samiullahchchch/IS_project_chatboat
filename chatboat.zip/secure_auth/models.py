from extensions import db
from flask_login import UserMixin
from datetime import datetime

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    is_blocked = db.Column(db.Boolean, default=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(50), default='user')
    # phone_number = db.Column(db.String(15), unique=True, nullable=True)  # Add phone_number field for OTP
    is_active = db.Column(db.Boolean, default=True)
    mfa_enabled = db.Column(db.Boolean, default=False)  # Multi-Factor Authentication enabled flag
    failed_login_attempts = db.Column(db.Integer, default=0)
    last_login_attempt = db.Column(db.DateTime, default=datetime.utcnow)  # Default to current UTC time
    
    def __repr__(self):
        return f"<User {self.email}>"
class TrustedDevice(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    device_id = db.Column(db.String(128), nullable=False)
    ip_address = db.Column(db.String(45))
    city = db.Column(db.String(100))
    country = db.Column(db.String(100))
    last_seen = db.Column(db.DateTime, default=datetime.utcnow)
    
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    user = db.relationship('User', backref=db.backref('trusted_devices', lazy=True))

    def __repr__(self):
        return f"<Device {self.device_id} for User {self.user_id}>"    
class ChatHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))  # Link to User table
    prompt = db.Column(db.Text, nullable=False)
    response = db.Column(db.Text, nullable=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

    user = db.relationship('User', backref='chat_history')    

    
# # Flask-Mail Configuration - Use environment variables
# app.config['MAIL_SERVER'] = os.environ.get('MAIL_SERVER', 'smtp.gmail.com')
# app.config['MAIL_PORT'] = int(os.environ.get('MAIL_PORT', 587))
# app.config['MAIL_USE_TLS'] = os.environ.get('MAIL_USE_TLS', 'true').lower() == 'true'
# app.config['MAIL_USERNAME'] = os.environ.get('sami325532@gmail.com')
# app.config['MAIL_PASSWORD'] = os.environ.get('mhof wdnf kamu zqro')
