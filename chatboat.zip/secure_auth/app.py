import os
import logging
from datetime import datetime, timedelta, timezone
from functools import wraps
from pathlib import Path
# =========================flask labraries============================
from flask import Flask, render_template, redirect, url_for, request, flash, session
from flask_login import login_user, login_required, logout_user, current_user
# ==================================================
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import joinedload
# =================================================================
from flask_mail import Message
import random

from flask_migrate import Migrate
import requests
import traceback
# ========================= models =======================
from models import TrustedDevice
from models import User
from models import ChatHistory
# ================== forms ======================================
from forms import SignupForm, LoginForm
from forms import ForgotPasswordForm,ResetPasswordForm
from forms import DeleteForm
# =========================================================


# ================extension =============
from extensions import ph
from extensions import db, login_manager, mail
from argon2.exceptions import VerifyMismatchError
from extensions import csrf

# ============limited request =================
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
# =============================ai model ===========================
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_core.prompts import PromptTemplate
from langchain.chains import RetrievalQA
from langchain_huggingface import HuggingFaceEndpoint
# from langchain.llms import HuggingFaceHub
from langchain_community.llms import HuggingFaceHub
# ========================== aes function ==========================
from utils.crypto_utils import encrypt_text, decrypt_text
from dotenv import load_dotenv
load_dotenv()
# from langchain_community.llms import HuggingFaceHub
# =======================================================




def role_required(required_role):
    def decorator(f):
        @wraps(f)
        def wrapper(*args, **kwargs):
            if not current_user.is_authenticated:
                flash("Please log in first.")
                return redirect(url_for('login'))

            if not session.get('is_verified'):  
                flash("Session not verified.")
                return redirect(url_for('verify_otp'))

            if current_user.role != required_role:
                flash("Access denied: insufficient permissions.")
                # return redirect(url_for('dashboard'))
                return redirect(url_for('chatbot'))

            return f(*args, **kwargs)
        return wrapper
    return decorator


def create_app():
 
    app = Flask(__name__)
    csrf.init_app(app)
    
    limiter = Limiter(
    get_remote_address,
    app=app,
    default_limits=["200 per day", "50 per hour"])
    migrate = Migrate(app, db)

    # =======================================Logging Configuration
    logging.basicConfig(
        filename='security.log',
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    logger = logging.getLogger('zero_trust_auth')

    # ==========================================App Configuration
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'fallback-secret-key-change-me')
    app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(minutes=15)

    #========================================== Database Configuration
    instance_path = Path(app.instance_path)
    instance_path.mkdir(exist_ok=True)
    app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{instance_path}/users.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    # ==============================================Flask-Mail Configuration
    app.config['MAIL_SERVER'] = 'smtp.gmail.com'
    app.config['MAIL_PORT'] = 587
    app.config['MAIL_USE_TLS'] = True
    app.config['MAIL_USERNAME'] = 'sami325532@gmail.com'
    app.config['MAIL_PASSWORD'] = 'mhof wdnf kamu zqro'
    app.config['MAIL_DEFAULT_SENDER'] = 'sami325532@gmail.com'


    # ===============================================Secure Session Handling
    app.config.update(
        SESSION_COOKIE_SECURE=True,
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE='Lax',
        PERMANENT_SESSION_LIFETIME=timedelta(minutes=15),
        SESSION_REFRESH_EACH_REQUEST=True
    )
    


    def get_user_ip():
     """Get user's IP address considering proxies."""
     return request.headers.get('X-Forwarded-For', request.remote_addr).split(',')[0].strip()
    # def get_user_ip():
    #     if app.config['ENV'] == 'development':
    #         return '8.8.8.8'  # Google's IP for testing
    #     return request.headers.get('X-Forwarded-For', request.remote_addr).split(',')[0].strip()


    def get_geolocation(ip):
        """Get geolocation data using ipapi.co."""
        try:
            res = requests.get(f'https://ipapi.co/{ip}/json/')
            if res.status_code == 200:
                data = res.json()
                return {
                    'ip': ip,
                    'city': data.get('city'),
                    'region': data.get('region'),
                    'country': data.get('country_name'),
                    'latitude': data.get('latitude'),
                    'longitude': data.get('longitude')
                }
        except Exception as e:
            return {'error': str(e)}
    

    #======================================================== Initialize Extensions
    db.init_app(app)    
    login_manager.init_app(app)
    mail.init_app(app)
    

    # ============================================================Configure login manager
    login_manager.login_view = 'login'
# ==========================================Routes==========================================================
    @login_manager.user_loader
    def load_user(user_id):
        return db.session.get(User, int(user_id))

    @app.after_request
    def add_security_headers(response):
        csp = (
            "default-src 'self'; "
            "style-src 'self' https://cdn.jsdelivr.net 'unsafe-inline'; "
            "script-src 'self' https://cdn.jsdelivr.net 'unsafe-inline' 'unsafe-eval'; "
            "script-src-elem 'self' https://cdn.jsdelivr.net 'unsafe-inline' 'unsafe-eval';"
        )
        response.headers['Content-Security-Policy'] = csp
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'SAMEORIGIN'
        response.headers['X-XSS-Protection'] = '1; mode=block'
        
        response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
    
        return response


    
    def get_user_ip():
        """Get client IP with proxy consideration"""
        return request.headers.get('X-Forwarded-For', request.remote_addr).split(',')[0].strip()

    def log_security_event(event_type, user_id=None, details=None):
        """Standardized security logging"""
        log_data = {
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'event': event_type,
            'user_id': user_id,
            'ip': get_user_ip(),
            'details': details
        }
        logger.info(log_data)

    #====================================================== Re-Verification Decorator (Zero Trust)
    def reverify_required(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user.is_authenticated:
                flash('You must be logged in to perform this action.')
                return redirect(url_for('login'))

            
            if current_user.mfa_enabled and not session.get('is_verified'):
                log_security_event('reverification_required', current_user.id, request.path)
                flash('Your session requires re-verification.')
                return redirect(url_for('verify_otp'))

            return f(*args, **kwargs)
        return decorated_function

        

    @app.route('/forgot-password', methods=['GET', 'POST'])
    def forgot_password():
        form = ForgotPasswordForm()

        if form.validate_on_submit():
            email = form.email.data
            user = User.query.filter_by(email=email).first()

            if not user:
                flash("No account found with that email.", "danger")
                return redirect(url_for('forgot_password'))

            otp = str(random.randint(100000, 999999))
            session['reset_email'] = email
            session['reset_otp'] = otp
            session['otp_expiry'] = datetime.now(timezone.utc).timestamp() + 300  

            try:
                msg = Message(subject="Password Reset Code", recipients=[email], body=f"Your OTP is: {otp}")
                mail.send(msg)
                flash("An OTP has been sent to your email.", "info")
                return redirect(url_for('reset_password'))
            except:
                flash("Failed to send email. Try again later.", "danger")

        return render_template('forgot_password.html', form=form)
    
    @app.route('/reset-password', methods=['GET', 'POST'])
    def reset_password():
        form = ResetPasswordForm()
    
        if form.validate_on_submit():
            otp = form.otp.data
            new_password = form.new_password.data
            stored_otp = session.get('reset_otp')
            email = session.get('reset_email')
    
            if datetime.now(timezone.utc).timestamp() > session.get('otp_expiry', 0):
                flash("OTP expired. Request again.", "warning")
                return redirect(url_for('forgot_password'))
    
            if otp != stored_otp:
                flash("Invalid OTP. Try again.", "danger")
                return redirect(url_for('reset_password'))
    
            user = User.query.filter_by(email=email).first()
            if user:
                user.password = ph.hash(new_password)
                db.session.commit()
                flash("Password updated successfully. You can now log in.", "success")
                session.clear()
                return redirect(url_for('login'))
    
            flash("Something went wrong.", "danger")
    
        return render_template('reset_password.html', form=form)


    @app.route('/signup', methods=['GET', 'POST'])
    def signup():
        form = SignupForm()
        if form.validate_on_submit():
            try:
                
                new_user = User(
                    email=form.email.data,
                    password = ph.hash(form.password.data),
                    role='user',
                    is_active=True,
                    mfa_enabled=True,
                    failed_login_attempts=0,
                    last_login_attempt=None
                )

                db.session.add(new_user)
                db.session.commit()

                log_security_event('user_registered', new_user.id)
                flash('Account created successfully. Please log in.')
                return redirect(url_for('login'))

            except Exception as e:
                db.session.rollback()
                log_security_event('registration_failed', details=str(e))
                flash('An error occurred during registration. Please try again.')

        return render_template('signup.html', form=form)

    
    @app.route('/login', methods=['GET', 'POST'])
    @limiter.limit("5 per minute")
    def login():
        logout_user()
        session.clear()

        form = LoginForm()

        if current_user.is_authenticated and session.get('is_verified'):
            return redirect(url_for('chatbot'))

        if form.validate_on_submit():
            user = User.query.filter_by(email=form.email.data).first()

            
            if not user:
                flash('No account found with this email.', 'danger')
                return render_template('login.html', form=form)

            # ======================================= Password  using Argon2
            valid_user = False
            try:
                ph.verify(user.password, form.password.data)
                valid_user = True
            except VerifyMismatchError:
                valid_user = False

            if not valid_user:
                user.failed_login_attempts += 1
                user.last_login_attempt = datetime.now(timezone.utc)
                db.session.commit()

                flash('Incorrect password. Please try again.', 'danger')
                return render_template('login.html', form=form)

            if user.failed_login_attempts >= 5:
                flash('Account locked due to multiple failed login attempts.', 'danger')
                return render_template('login.html', form=form)

            # ============================================================Reset failed attempts
            user.failed_login_attempts = 0
            user.last_login_attempt = datetime.now(timezone.utc)
            db.session.commit()

            # Device + Location Capture
            device_id = request.form.get('device_fingerprint')
            ip = request.headers.get('X-Forwarded-For', request.remote_addr).split(',')[0].strip()
            geo = get_geolocation(ip) or {}

            session['login_ip'] = geo.get('ip', ip)
            session['login_city'] = geo.get('city', 'Unknown')
            session['login_country'] = geo.get('country', 'Unknown')

            # =====================================================OTP flow
            if user.mfa_enabled:
                session['user_id'] = user.id
                otp = str(random.randint(100000, 999999))

                try:
                    msg = Message(
                        subject="Your OTP Code",
                        recipients=[user.email],
                        body=f"Your OTP code is: {otp}"
                    )
                    mail.send(msg)
                    session['otp'] = otp
                    session['otp_expiry'] = datetime.now(timezone.utc).timestamp() + 300
                    flash("OTP sent to your email.")
                    return redirect(url_for('verify_otp'))
                except Exception as e:
                    flash("Error sending OTP. Try again.")
                    return render_template('login.html', form=form)

            # ====================================================Final login if no MFA
            login_user(user)
            session['is_verified'] = not user.mfa_enabled

            # Device log
            existing_device = TrustedDevice.query.filter_by(user_id=user.id, device_id=device_id).first()

            if not existing_device:
                new_device = TrustedDevice(
                    device_id=device_id,
                    ip_address=ip,
                    city=geo.get('city'),
                    country=geo.get('country'),
                    user_id=user.id
                )
                db.session.add(new_device)
            else:
                existing_device.last_seen = datetime.now(timezone.utc)

            db.session.commit()

            if user.role == 'admin':
                return redirect(url_for('admin_panel'))
            else:
                return redirect(url_for('chatbot'))

        return render_template('login.html', form=form)




    @app.route('/verify_otp', methods=['GET', 'POST'])
    @limiter.limit("3 per minute")
    def verify_otp():
        if current_user.is_authenticated and not current_user.mfa_enabled:
             flash('MFA not required for this account.')
            #  return redirect(url_for('dashboard'))
             return redirect(url_for('chatbot'))


        if 'user_id' not in session or 'otp' not in session:
            flash('Invalid verification request.')
            return redirect(url_for('login'))

        user = db.session.get(User, session['user_id'])

        if not user:
            flash('Invalid verification request.')
            session.clear()
            return redirect(url_for('login'))

        if request.method == 'POST':
            otp = request.form.get('otp', '')

            #====================================================== check otp expiration
            if datetime.now(timezone.utc).timestamp() > session.get('otp_expiry', 0):
                flash('Verification code has expired. Please try logging in again.')
                return redirect(url_for('login'))

            if otp == session['otp']:
                
                login_user(user)
                session['is_verified'] = True
                session['verification_time'] = datetime.now(timezone.utc).timestamp()
                session.pop('otp', None)  
                session.pop('otp_expiry', None) 

                flash('Login successful!')
                if user.role == 'admin':
                    return redirect(url_for('admin_panel'))
                else:
                    # return redirect(url_for('dashboard'))
                    return redirect(url_for('chatbot'))

                
            else:
                flash('Invalid OTP. Please try again.')

        return render_template('verify_otp.html')
    
    
    # ==================================chatboat code=====================================
    @app.route('/chatbot', methods=['GET', 'POST'])
    @login_required
    @reverify_required
    @role_required('user')
    def chatbot():
        response_text = None
        if 'history' not in session:
            session['history'] = []

        if request.method == 'POST':
            user_input = request.form.get('prompt')
            if user_input:
                try:
                    HF_TOKEN = os.environ.get("HF_TOKEN")
                    HUGGINGFACE_REPO_ID = "mistralai/Mistral-7B-Instruct-v0.3"
                    DB_FAISS_PATH = "vectorstore/db_faiss"

                    embeddings = HuggingFaceEmbeddings(model_name='sentence-transformers/all-MiniLM-L6-v2')
                    vectorstore = FAISS.load_local(DB_FAISS_PATH, embeddings, allow_dangerous_deserialization=True)

                    prompt_template = PromptTemplate(
                        template="""
                            Use the pieces of information provided in the context to answer user's question.
                            If you don’t know the answer, just say that you don’t know, don’t try to make up an answer.
                            Don’t provide anything out of the given context.

                            Context: {context}
                            Question: {question}

                            Start the answer directly. No small talk please.
                        """,
                        input_variables=["context", "question"]
                    )

                    llm = HuggingFaceEndpoint(
                        repo_id=HUGGINGFACE_REPO_ID,
                        task="text-generation",
                        huggingfacehub_api_token=HF_TOKEN,
                        temperature=0.5,
                        max_new_tokens=512
                    )

                    qa_chain = RetrievalQA.from_chain_type(
                        llm=llm,
                        chain_type="stuff",
                        retriever=vectorstore.as_retriever(search_kwargs={"k": 3}),
                        return_source_documents=True,
                        chain_type_kwargs={"prompt": prompt_template}
                    )

                    result = qa_chain.invoke({"query": user_input})
                    response_text = result["result"]

                    
                    encrypted_prompt = encrypt_text(user_input)
                    encrypted_response = encrypt_text(response_text)

                    chat_record = ChatHistory(
                        user_id=current_user.id,
                        prompt=encrypted_prompt,
                        response=encrypted_response
                    )
                    db.session.add(chat_record)
                    db.session.commit()

                    session['history'].append({"prompt": user_input, "response": response_text})
                    session.modified = True

                except Exception as e:
                    traceback.print_exc()
                    response_text = f"Error: {str(e)}"

        # ================================================ user decrypt chat history 
        history = ChatHistory.query.filter_by(user_id=current_user.id).order_by(ChatHistory.timestamp.desc()).all()
        for chat in history:
            try:
                chat.prompt = decrypt_text(chat.prompt)
                chat.response = decrypt_text(chat.response)
            except:
                chat.prompt = "[Decryption Error]"
                print("ENCRYPTED CHAT:", chat.prompt)
                chat.response = "[Decryption Error]"

        return render_template('chatbot.html', response=response_text, history=history)


    
    
    
    
    
    
# =======================================================================
    @app.route('/chat-history')
    @login_required
    @reverify_required
    @role_required('user')
    def chat_history():
        history = ChatHistory.query.filter_by(user_id=current_user.id).order_by(ChatHistory.timestamp.desc()).all()

        # ✅ Decrypt each chat
        for chat in history:
            try:
                chat.prompt = decrypt_text(chat.prompt)
                chat.response = decrypt_text(chat.response)
            except:
                chat.prompt = "[Decryption Error]"
                chat.response = "[Decryption Error]"

        return render_template('chat_history.html', history=history)



    # ========================================logout ===================================
    @app.route('/logout')
    @login_required
    def logout():
        logout_user()
        session.clear()
        flash('You have been logged out.')
        return redirect(url_for('login'))
    
    
    
    # ================================= if two many request then this page render=================================
    @app.errorhandler(429)
    def ratelimit_handler(e):
        return render_template("429.html"), 429
    



    
    # @app.route('/admin')
    # @login_required
    # @role_required('admin')
    # def admin_panel():
    #     print("USER:", current_user.is_authenticated, current_user.email, current_user.role)
    #     return render_template('admin.html')
    
    # ================================ admin routes==================================
        

    @app.route('/admin')
    @login_required
    @role_required('admin')
    def admin_panel():
        users = User.query.options(joinedload(User.chat_history)).filter(User.role != 'admin').all()
        user_data = []

        for user in users:
            decrypted_chats = []
            for chat in user.chat_history:
                try:
                    decrypted_chats.append({
                        "prompt": decrypt_text(chat.prompt),
                        "response": decrypt_text(chat.response),
                        "timestamp": chat.timestamp
                    })
                except:
                    decrypted_chats.append({
                        "prompt": "[Decryption Error]",
                        "response": "[Decryption Error]",
                        "timestamp": chat.timestamp
                    })

            # ✅ Move this line INSIDE the loop
            user_data.append({
                'email': user.email,
                'chat_history': decrypted_chats,
                'role': user.role,
                'is_blocked': user.is_blocked,
                'form': DeleteForm()
            })

        return render_template('admin.html', user_data=user_data)

    # ========== chat histroy ==========
    @app.route('/admin/view/<email>')
    @login_required
    @role_required('admin')
    def view_user_history(email):
        user = User.query.filter_by(email=email).first()
        if not user:
            flash("User not found.", "danger")
            return redirect(url_for('admin_panel'))

        history = ChatHistory.query.filter_by(user_id=user.id).order_by(ChatHistory.timestamp.desc()).all()

        for chat in history:
            try:
                chat.prompt = decrypt_text(chat.prompt)
                chat.response = decrypt_text(chat.response)
            except:
                chat.prompt = "[Decryption Error]"
                chat.response = "[Decryption Error]"

        return render_template('admin_user_history.html', user=user, history=history)
    
    
    @app.route('/admin/search')
    @login_required
    @role_required('admin')
    def admin_search():
        email = request.args.get('email')
        if not email:
            flash("Please enter an email address to search.", "warning")
            return redirect(url_for('admin_panel'))

        user = User.query.filter_by(email=email).first()
        if not user:
            flash("No user found with that email.", "danger")
            return redirect(url_for('admin_panel'))

        decrypted_chats = []
        for chat in user.chat_history:
            try:
                decrypted_chats.append({
                    "prompt": decrypt_text(chat.prompt),
                    "response": decrypt_text(chat.response),
                    "timestamp": chat.timestamp
                })
            except:
                decrypted_chats.append({
                    "prompt": "[Decryption Error]",
                    "response": "[Decryption Error]",
                    "timestamp": chat.timestamp
                })

        return render_template('admin.html', user_data=[{
        'email': user.email,
        'chat_history': decrypted_chats,
        'role': user.role,
        'form': DeleteForm()
    }])



# ========== delete history via emial of each user ==========
    @app.route('/admin/delete/<email>', methods=['POST'])
    @login_required
    @role_required('admin')
    def delete_user_history(email):
        user = User.query.filter_by(email=email).first()
        if not user:
            flash("User not found.", "danger")
            return redirect(url_for('admin_panel'))

        ChatHistory.query.filter_by(user_id=user.id).delete()
        db.session.commit()
        flash(f"Chat history deleted for {email}.", "success")
        return redirect(url_for('admin_panel'))
    
    @app.route('/admin/block/<email>', methods=['POST'])
    @login_required
    @role_required('admin')
    def block_user(email):
        user = User.query.filter_by(email=email).first()
        if not user:
            flash("User not found.", "danger")
            return redirect(url_for('admin_panel'))

        if user.is_blocked:
            flash("User is already blocked.", "info")
        else:
            user.is_blocked = True
            db.session.commit()
            flash(f"User {email} has been blocked.", "warning")

        return redirect(url_for('admin_panel'))


    @app.route('/admin/unblock/<email>', methods=['POST'])
    @login_required
    @role_required('admin')
    def unblock_user(email):
        user = User.query.filter_by(email=email).first()
        if not user:
            flash("User not found.", "danger")
            return redirect(url_for('admin_panel'))

        if not user.is_blocked:
            flash("User is already unblocked.", "info")
        else:
            user.is_blocked = False
            db.session.commit()
            flash(f"User {email} has been unblocked.", "success")

        return redirect(url_for('admin_panel'))




    return app





app = create_app()


if __name__ == '__main__':
    with app.app_context():
        db.create_all()  
        
        if not User.query.first():
            admin = User(
                email='admin@example.com',
                password=ph.hash('admin123'), 
                role='admin',
                is_active=True
            )
            db.session.add(admin)
            db.session.commit()
    app.run(host='0.0.0.0', port=5000, debug=False, use_reloader=False)

