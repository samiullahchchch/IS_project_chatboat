from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import os
import base64
from dotenv import load_dotenv


load_dotenv()


AES_KEY_B64 = os.environ.get("AES_SECRET_KEY")

if not AES_KEY_B64:
    raise ValueError("Missing AES_SECRET_KEY in environment. Set it as a Base64-encoded 256-bit key.")

try:
    AES_KEY = base64.b64decode(AES_KEY_B64)
    if len(AES_KEY) != 32:
        raise ValueError("Invalid AES key length. Must be 256-bit key (32 bytes).")
except Exception as e:
    raise ValueError(f"Failed to decode AES_SECRET_KEY: {e}")


aesgcm = AESGCM(AES_KEY)

def encrypt_text(plain_text: str) -> str:
    nonce = os.urandom(12)  
    ciphertext = aesgcm.encrypt(nonce, plain_text.encode(), None)
    return base64.b64encode(nonce + ciphertext).decode()

def decrypt_text(encoded_text: str) -> str:
    try:
        data = base64.b64decode(encoded_text)
        nonce = data[:12]
        ciphertext = data[12:]
        return aesgcm.decrypt(nonce, ciphertext, None).decode()
    except Exception as e:
        return f"[Decryption Failed: {str(e)}]"
