from flask_sqlalchemy import SQLAlchemy
from argon2 import PasswordHasher
from flask_login import LoginManager
from flask_mail import Mail
from flask_wtf import CSRFProtect

# Create extension instances without initializing them
db = SQLAlchemy()
ph = PasswordHasher(time_cost=3, memory_cost=65536, parallelism=2)
login_manager = LoginManager()
mail = Mail()
csrf = CSRFProtect()